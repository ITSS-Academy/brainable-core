import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn
} from "typeorm";
import { Profile } from "./Profile";
import { Question } from "./Question";
import { type } from "node:os";
import { Categories } from "./Categories";

@Entity()
export class Quiz {
  constructor(title: string, description: string, isPublic: boolean, category: string, imgUrl: string) {
    this.title = title;
    this.description = description;
    this.isPublic = isPublic;
    this.imgUrl = imgUrl;
    this.category = category;
  }

  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  title: string;

  @Column()
  description: string;

  @Column()
  isPublic: boolean;

  @Column()
  imgUrl: string;


  @CreateDateColumn({ type: "timestamptz" })
  createdAt: Date;

  @ManyToOne(() => Profile, (profile) => profile.uid)
  @JoinColumn([
    { name: "authorUid", referencedColumnName: "uid" },
    { name: "authorEmail", referencedColumnName: "email" }
  ])
  authorId: Profile;

  @OneToMany(() => Question, (question) => question.quizId)
  questions: Question[];

  @ManyToOne(() => Categories, (category) => category.uid)
  @JoinColumn({ name: "categoryId" })
  category: string;
}
