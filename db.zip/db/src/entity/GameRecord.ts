import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Game } from './Game';
import { Question } from './Question';

@Entity()
export class GameRecord {
  constructor(
    gameId: string,
    questionId: string,
    playerName: string,
    responseTimeInMs: number,
    answer: number,
  ) {
    this.gameId = gameId;
    this.questionId = questionId;
    this.playerName = playerName;
    this.responseTimeInMs = responseTimeInMs;
    this.answer = answer;
  }

  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Game, (game) => game.id)
  @JoinColumn()
  gameId: string;

  @OneToOne(() => Question, (question) => question.id)
  @JoinColumn()
  questionId: string;

  @Column()
  playerName: string;

  @Column()
  responseTimeInMs: number;

  @Column()
  answer: number;
}
